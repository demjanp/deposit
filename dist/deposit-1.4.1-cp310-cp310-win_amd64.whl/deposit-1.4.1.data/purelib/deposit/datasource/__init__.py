from deposit.datasource.abstract_datasource import AbstractDatasource
from deposit.datasource.memory import Memory
from deposit.datasource.json import JSON
from deposit.datasource.pickle import Pickle
from deposit.datasource.db import DB
from deposit.datasource.db_rel import DBRel
