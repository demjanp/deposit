from deposit.store.abstract_dtype import AbstractDType

class DDict(AbstractDType):
	
	pass
