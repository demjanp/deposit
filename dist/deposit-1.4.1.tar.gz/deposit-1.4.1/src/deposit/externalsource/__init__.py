from deposit.externalsource.abstract_externalsource import AbstractExternalsource
from deposit.externalsource.xlsx import XLSX
from deposit.externalsource.csv import CSV
from deposit.externalsource.shp import SHP
